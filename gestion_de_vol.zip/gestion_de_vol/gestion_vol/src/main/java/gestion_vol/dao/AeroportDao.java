package gestion_vol.dao;

import com.genericdao.api.GenericDao;

import gestion_vol.bo.Aeroport;




public interface AeroportDao extends GenericDao<Aeroport,Long>{

}
