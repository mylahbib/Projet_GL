package gestion_vol.dao;

import com.genericdao.api.GenericDao;

import gestion_vol.bo.Reservation;


public interface ReservationDao extends GenericDao<Reservation,Long>{

}
