package gestion_vol.dao;

import com.genericdao.api.GenericDao;

import gestion_vol.bo.Passager;


public interface PassagerDao extends GenericDao<Passager,Long>{

}
