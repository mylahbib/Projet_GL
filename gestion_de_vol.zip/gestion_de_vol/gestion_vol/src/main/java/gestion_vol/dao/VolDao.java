package gestion_vol.dao;


import com.genericdao.api.GenericDao;


import gestion_vol.bo.Vol;

public interface VolDao extends GenericDao<Vol,Long>{
	
	

}
