package gestion_vol.dao;

import com.genericdao.api.GenericDao;

import gestion_vol.bo.Client;


public interface ClientDao extends GenericDao<Client,Long>{

}
