package gestion_vol.dao;

import com.genericdao.api.GenericDao;

import gestion_vol.bo.Compagnie;



public interface CompagnieDao extends GenericDao<Compagnie,Long>{

}
