/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Application;
import java.sql.*;

/**
 *
 * @author ayoub
 */
public class Parametre {
    
    public static Connection conn;
    public static String url = "jdbc:mysql://localhost:3306/gestion_de_dons";
    public static String pwd="";
    public static String login="root";
     
 
    private Parametre() {
        try {
            Class.forName("com.mysql.jdbc.driver");
            conn = DriverManager.getConnection(url, login, pwd);
        } catch (SQLException | ClassNotFoundException ex) {
            System.out.println(ex.toString());
        }
    }
 
    public static Connection getInstance(){
        if(conn == null){
            Parametre aa = new Parametre();
        }
        return conn;
    }
     
    
    
    
    

 /* // public static String IPHOST ="127.0.0.1";
 
    public static String HOST_BD = "jdbc:mysql://127.0.0.1//3306/gestion_de_dons";
    public static String USERNAME_DB = "root";
    public static String PASSWORD_DB = "";

    
     public static int PORT =11111;
      public static String USER;
   */
}
    
  
                      