package GUI;


import java.sql.*;
import javax.swing.*;
import java.sql.Connection;
import java.sql.Statement;
import java.net.Socket;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;


class MySqlConnect {

    Connection conn;
     Statement statement;
        String sql;
    
    public static Connection ConnectDB(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
	  Connection conn=DriverManager.getConnection("jdbc:mysql://localhost/gestion_vols","root","");
          //  JOptionPane.showMessageDialog(null,"Connected to database");
            return conn;
        
        }
        catch(Exception e){
    JOptionPane.showMessageDialog(null, e);
    return null;
    
}
    
}
    
    
    public ResultSet exécutionQuery(String sql){
    ConnectDB();
         ResultSet result=null;
         
         try {
   
    statement= conn.createStatement();
    result= statement.executeQuery(sql);
    System.out.println(sql);
    } catch(SQLException ex)
    {
        System.err.println(ex);}

         return result;

}
     
    
     public String exécutionUpdate(String sql){
         ConnectDB();
         String result="";
         
          try {
   
            statement = conn.createStatement();
   statement.executeUpdate(sql);
   result=sql;
    
    } catch(SQLException ex)
      {
        result=ex.toString();}

         return result;

}
         
     
     public DefaultTableModel creatmodel(ResultSet rs,String colon[]){
          DefaultTableModel model=new DefaultTableModel();
          model.setColumnIdentifiers(colon);
          try {
              Object tabo[] = { };
        while (rs.next()){ 
                for(int i=1;i<=colon.length;i++) tabo[i]=rs.getObject(colon[i]);
        	model.addRow(tabo); 
        }

        }catch ( SQLException e ) {}
               return model;
     
         
         
     }
     
     
     public ResultSet querySelectAll(String nomTable){
    ConnectDB();
        sql = "select * from" + nomTable;
         System.out.println(sql);
            return this.exécutionQuery(sql);
        
}
     
     
      public ResultSet querySelectAll(String nomTable,String état){
    ConnectDB();
        sql = "select * from" + nomTable + "where" + état;
         System.out.println(sql);
            return this.exécutionQuery(sql);
        
}

       public ResultSet querySelect(String[] nomColonne,String nomTable){
    ConnectDB(); 
    int i;
        sql = "select";
    for(i=0;i<=nomColonne.length-1;i++){
        sql+=nomColonne[i];
        if(i<nomColonne.length - 1){
           sql+=","; 
        }
    }
        sql+="from" +nomTable;
        return this.exécutionQuery(sql);
       }  

       
       public ResultSet fcselectCommand(String[] nomColonne,String nomTable, String état){
    ConnectDB(); 
    int i;
        sql = "select";
    for(i=0;i<=nomColonne.length-1;i++){
        sql+=nomColonne[i];
        if(i<nomColonne.length - 1){
           sql+=","; 
        }
    }
        sql+="from"+nomTable+"where"+ état;
        return this.exécutionQuery(sql);
       }  
       
       
       
       
       public String queryInsert(String nomTable,String[] contenuTableau){
    ConnectDB(); 
    int i;
    
    sql= "insert into" + nomTable + "VALUES(";
    for(i=0;i<=contenuTableau.length-1;i++){
        sql+="'"+contenuTableau[i]+"'";
        if(i<contenuTableau.length - 1){
           sql+=","; 
        }
    }
        sql+=")";
        return this.exécutionUpdate(sql);
    
       /* sql = "select";
    for(i=0;i<=contenuTableau.length-1;i++){
        sql+="'"+contenuTableau[i]+"'";
        if(i<contenuTableau.length - 1){
           sql+=","; 
        }
    }
        sql+=",";
        return this.executionUpdate(sql);*/
       }  
       
   
            public String queryInsert(String nomTable,String[] nomColonne,String [] contenuTableau){
    ConnectDB(); 
    int i;
        sql = "insert into" + nomTable+"(";
    for(i=0;i<=nomColonne.length-1;i++){
        sql+=nomColonne[i];
        if(i<nomColonne.length - 1){
           sql+=","; 
        }
    }
        sql+=")VALUES(";
        for(i=0;i<=contenuTableau.length-1;i++){
        sql+="'"+contenuTableau[i]+"'";
        if(i<contenuTableau.length - 1){
           sql+=","; 
        }
    }
        sql+=")";
        return this.exécutionUpdate(sql);
       }   
       
       
       
            
  public String queryUpdate(String nomTable,String[] nomColonne,String [] contenuTableau,String état){
    ConnectDB(); 
    int i;
        sql = "update" + nomTable+ "set";
    for(i=0;i<=nomColonne.length-1;i++){
        sql+=nomColonne[i] + "='" + contenuTableau[i]+ "'";
        if(i<nomColonne.length - 1){
           sql+=","; 
        }
    }
        
        sql+="where" + état;
        return this.exécutionUpdate(sql);
       }   
       
       public String queryDelete(String nomtable){
           ConnectDB();
           sql="delete from" + nomtable;
           return this.exécutionUpdate(sql);
           
       }
       
       
       public String queryDelete(String nomtable,String état){
           ConnectDB();
           sql="delete from" + nomtable+ "where" + état ;
           return this.exécutionUpdate(sql);
           
       }
       
       
       
       
}
